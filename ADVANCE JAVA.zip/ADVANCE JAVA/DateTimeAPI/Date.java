import java.time.*;
import java.time.format.DateTimeFormatter;

public class Date {
    public static void LocalDateTimeApi()
    {
        //Current date
        LocalDate date = LocalDate.now();
        System.out.println("Current date is = "+date);
        
         //Current time
        LocalTime time = LocalTime.now();
        System.out.println("Current time is = "+time);

        //will give us the current time and date
        LocalDateTime current = LocalDateTime.now();
        System.out.println("current Date and time = "+current);

        //Perticuler format
        DateTimeFormatter format =DateTimeFormatter.ofPattern("dd-MM-yy HH:mm:ss");
        String formatedDateTime = current.format(format);
        System.out.println("formatted manner = "+formatedDateTime);

        //Printing months,day,seconds
        Month month = current.getMonth();
        int day = current.getDayOfMonth();
        int seconds = current.getSecond();
        System.out.println("month :"+month +"day :"+day +"seconds :"+seconds);


        //Republic day
        LocalDate date2 = LocalDate.of(1950, 1, 26);
        System.out.println("republic day == "+date2);
    }
    public static void main(String[] args) {
        LocalDateTimeApi();
    }
}
