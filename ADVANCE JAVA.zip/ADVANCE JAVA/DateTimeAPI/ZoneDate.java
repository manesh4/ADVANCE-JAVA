import java.time.*;
import java.time.format.DateTimeFormatter;

public class ZoneDate {
    public static void ZonedDisp()
    {
        //Current Zone 
        ZonedDateTime currentZone = ZonedDateTime.now();
        System.out.println("current zone  ="+currentZone.getZone());

        //Asia/Tokyo
        ZoneId tokyo = ZoneId.of("Asia/Tokyo");
        ZonedDateTime tokyoZone = currentZone.withZoneSameInstant(tokyo);
        System.out.println("tokyo time zone ="+tokyoZone);

        //formatted tokyo Zone
        DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yy HH:mm:ss");
        String formatedDateTime = tokyoZone.format(format);
        System.out.println("formatted tokyo zone = " +formatedDateTime);
    }
    public static void main(String[] args) {
        ZonedDisp();
    }
}
