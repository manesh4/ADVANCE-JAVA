//@Annotation
@FunctionalInterface
interface Square{
    int calculate(int x);
}

public class Annotation {
    public static void main(String[] args) {
        int a=5;
        //Lambda Expression
        Square s=(int x)->x*x;
        int res=s.calculate(a);
        System.out.println(res);

    }
    
}
