//InterfaceDefault
interface TestInter{
    //abstract method
    public void sqr(int x);

    //Default Method
    default void show()
    {
        System.out.println("default method");
    }
    //Static method
    static void display()
    {
        System.out.println("Static method");
    }
}

public class InterfaceDefault implements TestInter{
    public void sqr(int x)
    {
        System.out.println(x*x);
    }
    public static void main(String[] args) {
        InterfaceDefault i = new InterfaceDefault();
        i.sqr(2);
        i.show();
        TestInter.display();
    }
    
}
