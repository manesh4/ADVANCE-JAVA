import java.util.function.Predicate;

public class Sample {
    public static void main(String[] args) {
        //Creating Predicate
        Predicate<Integer> less = i->(i<10);
        //call
        System.out.println(less.test(5));
    }
    
}
