import java.util.function.Predicate;
public class Test {
    public static void main(String[] args) {
        
        Predicate<Integer> great = (i)->i>10;
        Predicate<Integer> less = (i)->i<20;

        boolean res1 = great.and(less).test(15);
        System.out.println(res1);

        boolean res2 = great.and(less).negate().test(15);
        System.out.println(res2);
    }
    
}
