import java.util.regex.Pattern;

public class PatternSearching {
    public static void main(String[] args) {
        System.out.println(Pattern.matches("[a-z]", "p"));
        System.out.println(Pattern.matches("[a-z]", "prem"));
        
        //Checking all String
        System.out.println(Pattern.matches("[b-z]", "a"));

        //Chrck if all element are in range a to z & A to Z
        System.out.println(Pattern.matches("[a-zA-Z]+", "preM"));

        //check if element is not in range
        System.out.println(Pattern.matches("[^a-z]?", "g"));

        // Check if all the element are either p,r,e,m
        System.out.println(Pattern.matches("[prem]*", "premprem")); 





        //check if all elements are numbers
        System.out.println(Pattern.matches("\\d+", "1234"));

        //check if all elements are non-numbers
        System.out.println(Pattern.matches("\\D+", "1234"));
        System.out.println(Pattern.matches("\\D+", "prem")); 

        //check if all elements are non spaces
        System.out.println(Pattern.matches("\\S+", "pr em"));
    }
    
}
