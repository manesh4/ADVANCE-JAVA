class TestDaemon extends Thread 
{
    public void run()
        {
            if(Thread.currentThread().isDaemon());
            {
                System.out.println("Its Daemon Thread");
            }
            else{
                System.out.println("Its user Thread");
            }
        }
}

   

    public class Daemon {
    public static void main(String[] args) throws InterruptedException {
        TestDaemon t1 =new TestDaemon();
        TestDaemon t2 =new TestDaemon();
        TestDaemon t3 =new TestDaemon();

        t1.setDaemon(true);
        t1.start();
        t2.start();
        t3.start();

        
    }


}
