class Demo1 extends Thread {
    public void run()
    {
        synchronized(this)
        {
            System.out.println(Thread.currentThread().getName()+"......start");

            try{
                this.wait();
            }catch(InterruptedException e){
                e.printStackTrace();
            }
            System.out.println(Thread.currentThread().getName()+"......notified");
        }
    }
}

class Demo2 extends Thread {
    Demo1 demo1;
    Demo2(Demo1 demo1){
        this.demo1=demo1;
    }
    public void run()
    {
        synchronized(this.demo1)
        {
            System.out.println(Thread.currentThread().getName()+"......start");

            try{
                this.demo1.wait();
            }catch(InterruptedException e){
                e.printStackTrace();
            }
            System.out.println(Thread.currentThread().getName()+"......notified");
        }
    }
}

class Demo3 extends Thread {
    Demo1 demo1;
    Demo3(Demo1 demo1){
        this.demo1=demo1;
    }
    public void run()
    {
        synchronized(this.demo1)
        {
            System.out.println(Thread.currentThread().getName()+"......start");
            
            this.demo1.notifyAll();
           
            //System.out.println(Thread.currentThread().getName()+"......notified");
        }
    }
}
public class NotifyAll {
    public static void main(String[] args) throws InterruptedException {
        Demo1 demo1 = new Demo1();
        Demo2 demo2 = new Demo2(demo1);
        Demo3 demo3 = new Demo3(demo1);

        Thread t1 = new Thread (demo1,"Thread-1");
        Thread t2 = new Thread (demo2,"Thread-2");
        Thread t3 = new Thread (demo3,"Thread-3");

        t1.start();
        t2.start();
        Thread.sleep(100);
        t3.start();
                

        
    }
    
}
