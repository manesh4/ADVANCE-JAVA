import java.util.*;
import java.io.*;

class MyThreadOne extends Thread {
    public void show()
    {
        for(int i=0;i<5;i++)
        {
            System.out.println("first");
        }
    }
}
class MyThreadTwo extends Thread {
    public void show()
    {
        for(int i=0;i<5;i++)
        {
            System.out.println("Second");
        }
    }
}
public class SimpleThread {
    public static void main(String[] args) {
        MyThreadOne obj1=new MyThreadOne();
        MyThreadTwo obj2=new MyThreadTwo();

        obj1.show();
        obj2.show();
    
    }
    
} 
