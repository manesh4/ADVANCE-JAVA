import java.io.*;
class MyThread implements Runnable {
    private boolean exit;
    private String name;
    Thread t;
    MyThread (String tname)
    {
        name = tname;
        t=new Thread (this.name);
        System.out.println("new thread" +t);
        exit=false;
        t.start();
    }
    public void run()
    {
        int i=0;
        while (!exit)
        {
            System.out.println(name + " : "+i);
            i++;
            try{
                Thread.sleep(100);
            }
            catch(InterruptedException e)
            {
                System.out.println("caughting by " +e);
            }
        }
        System.out.println("Stopped......!");
    }
    public void stop(){
        exit=true;
    }
}

public class Stop {
    public static void main(String[] args) {
        
        MyThread t1 = new MyThread("First-Thread");
        MyThread t2 = new MyThread("Second-Thread");

        try{
            Thread.sleep(500);
            t1.stop();
            t2.stop();
            Thread.sleep(500);
        }catch(InterruptedException e)
        {
            System.out.println("caughting by " +e);
        }
        System.out.println("exit");
    }
    
}
