import java.util.*;
import java.io.*;

class MythreadOne extends Thread{
//run method inside runnable interface

public void show()
{
    for(int i=0;i<5;i++)
    {
        System.out.println("first");
    }
}
}

//class 2
class MythreadTwo extends Thread{
//run method inside runnable interface

public void show()
{
    for(int i=0;i<5;i++)
    {
        System.out.println("second");
    }
}
}

public class SimpleThread {
    public static void main(String args[]) {
     MythreadOne obj1 = new MythreadOne();
     MythreadTwo obj2 = new MythreadTwo();
     
     obj1.show();
     obj2.show();
    }
}