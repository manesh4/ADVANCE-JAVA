import java.util.*;
import java.util.stream.Stream;
import java.util.stream.IntStream;

public class Boxed {
    public static void main(String[] args) {
        IntStream stream = IntStream.range(3, 8);
        Stream<Integer> stream1 = stream.boxed();
        // stream1.forEach(System.out::println);

         Stream<Object> stream2 = Stream.concat(stream1,Stream.of("Java ","Programing","Language"));

         stream2.forEach(System.out::println);
    }
}
