import java.util.*;
import java.util.stream.*;

public class DemoStream {
    public static void main(String[] args) {
        
        //create list of integer
        List<Integer> no = new ArrayList<>();
        no = Arrays.asList(2,3,4,5);
        //map method;

        List<Integer> square = no.stream().map(x->x*x).collect(Collectors.toList());
        System.out.println(square);
        
        
        //create a list of string
         List<String> names = Arrays.asList("Ref","Collect","Stream");
        //filter method;

        List<String> result = names.stream().filter(s->s.startsWith("C")).collect(Collectors.toList());
        System.out.println(result);
        
           //sorted method
           List<String> show = names.stream().sorted().collect(Collectors.toList());
           System.out.println(show);
           
        //create list of integer
        List<Integer> nos = Arrays.asList(2,3,4,5,2);
        
        //coolcet method to return set;

        Set<Integer> squareSet = nos.stream().map(x->x*x).collect(Collectors.toSet());
        System.out.println(squareSet);
        
        //forEach method
        
        nos.stream().map(x->x*x).forEach(y->System.out.println(y));
        
        //reduce method
        int even  = nos.stream().filter(x->x%2==0).reduce(0,(ans,i)->ans+i);
        System.out.println(even);
    }
}
