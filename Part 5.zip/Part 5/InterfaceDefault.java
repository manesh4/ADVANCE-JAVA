interface TestInter
{
    //abstract method
    public void sqr(int x);
    //default method
    default void show()
    {
        System.out.println("default method");
    }

    //static method
    static void display()
    {
        System.out.println("static method");
    }
}

public class InterfaceDefault implements TestInter {
    public void sqr(int x)
{
    System.out.println(x*x);
}
    public static void main(String[] args) {

        InterfaceDefault i = new InterfaceDefault();
        i.sqr(2);
        i.show();
        TestInter.display();
    }
}
