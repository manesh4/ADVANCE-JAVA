interface Fun{
    void abstractFun(int x);
  
}
public class Lambda {
    public static void main(String[] args) {
        Fun obj = (int x) -> System.out.println(2*x);
        obj.abstractFun(5);
    }
}
