
public class LambdaMultiple {
    interface Inter1{
        int operation(int a, int b);
    }
    interface Inter2{
        void getMsg(String msg );
    }
    private int operate(int a, int b,Inter1 obj)
    {
        return obj.operation(a, b);
    }
    public static void main(String[] args) {
        Inter1 add = (int x, int y) -> x+y;
        Inter1 multy = (int x, int y) -> x*y;

        LambdaMultiple m = new LambdaMultiple();
        System.out.println("Addition is = "+m.operate(6, 3, add));
         System.out.println("Multiplication is = "+m.operate(6, 3, multy));
    }
}
