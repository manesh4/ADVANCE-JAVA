
class MyThreadOne extends Thread
{
    public void run()
    {
        System.out.println("Thread one is running");
    }
}

class MyThreadSecond extends Thread{
    public void run()
    {
       System.out.println("Thread second is running");
    }
}
public class Main {

    public static void main(String[] args) 
    {
        MyThreadOne mt1 = new MyThreadOne();
        MyThreadSecond mt2 = new MyThreadSecond();

        mt1.run();
        mt2.run();
    }
}
