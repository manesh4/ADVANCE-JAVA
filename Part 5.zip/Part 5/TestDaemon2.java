public class TestDaemon2 extends Thread {
    public void run()
    {
        if(Thread.currentThread().isDaemon())
        {
            System.out.println("its a daemon thread");
        }
        else{
            System.out.println("its user thread");
        }
    }
    public static void main(String[] args) {
        TestDaemon t1 = new TestDaemon();
        TestDaemon t2 = new TestDaemon();

     
        t1.start();
        t1.setDaemon(true);
        t2.start();
   
    }
}
