public class WithFunctionalInterface {
    public static void main(String[] args) {
        //creating anonymous inner class
        new Thread(()-> {
                System.out.println("new thread created");
        }).start();
    }
}
