public class WithoutFunctionalInterface {
    public static void main(String[] args) {
        //creating anonymous inner class
        new Thread(new Runnable() {
           @Override public void run()
            {
                System.out.println("new thread created");
            }
        }).start();
    }
}
