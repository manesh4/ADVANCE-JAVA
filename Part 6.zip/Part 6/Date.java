import java.time.*;
import java.time.format.DateTimeFormatter;

public class Date {
   public static void LocalDateTimeApi()
   {
     //current date
    LocalDate date = LocalDate.now();
    System.out.println("current date is = "+date);

    //current time
    LocalTime time = LocalTime.now();
    System.out.println("current time is = "+time);

    //will give us the current time and date
    LocalDateTime current = LocalDateTime.now();
    System.out.println("current date and time = "+current);
   

   //perticuler format
   DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
   String formatedDateTime = current.format(format);
     System.out.println("formatted manner = "+formatedDateTime);

     //printing monts , days, seconds.
     Month month = current.getMonth();
     int day = current.getDayOfMonth();
     int seconds = current.getSecond();
     
     System.out.println("months : "+month+" day : "+day+" seconds:"+seconds);

     //republice day
     LocalDate date2 = LocalDate.of(1950, 1, 26);
     System.out.println("republic day == "+date2);

   }
    public static void main(String[] args) {
        LocalDateTimeApi();
    }
}
