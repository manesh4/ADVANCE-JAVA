import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class PatternSearching {
    public static void main(String[] args) {
        
        //custom pattern
        Pattern pattern = Pattern.compile("hello");
        // search above pattern in helloforhello.com
        Matcher m = pattern.matcher("helloforhello.com");
        //finding string using find()
        while(m.find())
        {
            System.out.println("pattern found from "+m.start()+
            " to "+(m.end()-1));
        }
    }
}
