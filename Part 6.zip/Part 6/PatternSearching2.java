import java.io.*;
import java.util.regex.*;
public class PatternSearching2 {
    public static void main(String[] args) {

        // System.out.println(Pattern.matches("[a-z]","p"));
        // System.out.println(Pattern.matches("[a-z]","prem"));

        //checking all string 
          // System.out.println(Pattern.matches("[b-z]?","a"));
        //   check if all element are in range a to z & A to Z
          // System.out.println(Pattern.matches("[a-zA-Z]+","preM"));
           //check if element is not in range 
          // System.out.println(Pattern.matches("[^a-z]?","g"));
          // check if all the elements are either p,r,e,m
          // System.out.println(Pattern.matches("[prem]*","premprem"));


        //check if all elemnets are numbers
          // System.out.println(Pattern.matches("\\d+","1234"));
           //check if all elemnets are non-numbers
          // System.out.println(Pattern.matches("\\D+","1234"));
          //  System.out.println(Pattern.matches("\\D+","prem"));
                //check if all elemnets are non spaces 
          // System.out.println(Pattern.matches("\\S+","prem"));
           

    }
}
