import java.util.regex.Pattern;
public class Patternregex{
    public static void main(String[] args) {
        System.out.println(Pattern.matches("helloforhello","helloforhello"));
    
        System.out.println(Pattern.matches("h*hello*", "hellofor"));
    }
}