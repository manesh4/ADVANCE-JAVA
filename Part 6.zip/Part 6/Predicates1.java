import java.util.function.Predicate;
public class Predicates1 {
    public static void main(String[] args) {
        //creating predicate
        Predicate<Integer> less = i->(i<10);
        //call
        System.out.println(less.test(5));
    }
}
