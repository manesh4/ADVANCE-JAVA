import java.util.Random;
public class RandomNum {
    public static void main(String[] args) {
        Random r = new Random();

        int r1 = r.nextInt(1000);
        int r2 = r.nextInt(1000);

        System.out.println("r1 = "+r1);
        System.out.println("r2 = "+r2);
    }
}
