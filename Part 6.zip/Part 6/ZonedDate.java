import java.time.*;
import java.time.format.DateTimeFormatter;

public class ZonedDate {

    public static void ZonedDisp()
    {
         //current zone
        ZonedDateTime currentZone = ZonedDateTime.now();
        System.out.println("current zone = "+currentZone.getZone());
        //Asia/Tokyo
        ZoneId tokyo = ZoneId.of("Asia/Tokyo");
        ZonedDateTime tokyoZone = currentZone.withZoneSameInstant(tokyo);
        System.out.println("tokyo time zone is = "+tokyoZone);

        //formatted tokyo zone
         DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
   String formatedDateTime = tokyoZone.format(format);
     System.out.println("formatted tokyo zone  = "+formatedDateTime);
    }
    public static void main(String[] args) {
       ZonedDisp();
    }
}
