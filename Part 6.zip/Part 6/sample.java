
import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class sample {

    public static void main(String[] args) {
      Pattern pattern = Pattern.compile("hello");
      Matcher m = pattern.matcher("helloforhello");

      while(m.find())
      {
        System.out.println("pattern found from "+m.start()+ " to "+(m.end()-1));
      }
}
}